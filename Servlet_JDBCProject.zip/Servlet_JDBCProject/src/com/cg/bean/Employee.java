package com.cg.bean;

import java.sql.Date;

public class Employee {
	private Integer id;
	private String name;
	private String designation;
	private Date date;
	private Double salary;
	private String city;
	public Employee() {
	super();
	}
	public Employee(Integer id, String name, String designation, Date date, Double salary, String city) {
		super();
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.date = date;
		this.salary = salary;
		this.city = city;
	}
	public Employee(String name, String designation, Date date, Double salary, String city) {
		super();
		this.name = name;
		this.designation = designation;
		this.date = date;
		this.salary = salary;
		this.city = city;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
		
	

}
