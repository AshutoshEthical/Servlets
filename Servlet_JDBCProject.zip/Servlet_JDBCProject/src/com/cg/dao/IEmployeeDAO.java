package com.cg.dao;

import com.cg.bean.Employee;
import com.cg.exceptions.EMSException;

public interface IEmployeeDAO {
	
	public int addEmployee(Employee employee) throws EMSException;

}
