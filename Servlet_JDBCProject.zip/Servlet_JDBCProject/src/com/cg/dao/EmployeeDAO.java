package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.bean.Employee;
import com.cg.exceptions.EMSException;
import com.cg.utility.JDBCUtility;

public class EmployeeDAO implements IEmployeeDAO{

	Connection connection=null ;
	PreparedStatement statement = null;
	
	
	@Override
	public int addEmployee(Employee employee) throws EMSException {
		
		connection = JDBCUtility.getConnection();
		String insertQuery ="insert into pune_intern_batch values(hibernate_sequence.nextval,?,?,?,?,?)";
		int id=0;
		try
		{
			statement = connection.prepareStatement(insertQuery);
			statement.setString(1, employee.getName());
			statement.setString(2, employee.getDesignation());
			statement.setDate(3, employee.getDate());
			statement.setDouble(4, employee.getSalary());
			statement.setString(5, employee.getCity());
		id= statement.executeUpdate();
		
		}
		
		catch(SQLException e)
		{
			throw new EMSException("Problem occurred while creating ps object");
		}
		
		
		
		return id;
	}

}
