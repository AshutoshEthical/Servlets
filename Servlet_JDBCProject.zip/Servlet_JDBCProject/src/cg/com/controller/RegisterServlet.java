package cg.com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Employee;
import com.cg.dao.EmployeeDAO;
import com.cg.dao.IEmployeeDAO;
import com.cg.exceptions.EMSException;
@WebServlet("/register")

public class RegisterServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	PrintWriter out = response.getWriter();
	IEmployeeDAO employeeDAO = new EmployeeDAO();
	
	String name = request.getParameter("empname");
	String designation = request.getParameter("desig");
	String date = request.getParameter("doj");
	
	Date doj =Date.valueOf(date);
	
	double salary = Double.parseDouble(request.getParameter("salary"));
	String city=request.getParameter("city");
	
	Employee employee = new Employee(name,designation,doj,salary,city);
	int result=0;
	try
	{
		result = employeeDAO.addEmployee(employee);
		
		if(result>0)
			out.println(""+result+" rows inserted");
		else
			out.println("id is not generated");
	}
	catch(EMSException e)
	{
		System.out.println(e.getMessage());
	}
	}
	
}
